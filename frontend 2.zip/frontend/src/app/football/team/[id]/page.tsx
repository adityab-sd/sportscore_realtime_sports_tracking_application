import Link from "next/link";
import { notFound } from "next/navigation";
import {
  getTeam, getRoster, getTeamInjuries, getTeamSchedule,
  getTeamRecord, getTeamDepthChart, getNews,
} from "@/lib/api/espn";
import { leagueName } from "@/types/football";
import TeamLogo from "@/components/football/TeamLogo";
import SquadList from "@/components/football/SquadList";
import { TeamScheduleList, TeamRecordCard, InjuryList, DepthChart } from "@/components/football/TeamDetailCards";

export const dynamic = "force-dynamic";
interface Props { params: Promise<{ id: string }>; searchParams: Promise<{ league?: string }> }

export default async function TeamPage({ params, searchParams }: Props) {
  const { id } = await params;
  const { league = "eng.1" } = await searchParams;

  const [team, roster, injuries, scheduleRaw, recordRaw, depthRaw, news] = await Promise.all([
    getTeam(league, id),
    getRoster(league, id),
    getTeamInjuries(league, id),
    getTeamSchedule(league, id),
    getTeamRecord(league, id),
    getTeamDepthChart(league, id),
    getNews(league, 5),
  ]);

  if (!team) return notFound();

  // Filter team-specific news
  const teamNews = news.filter(n =>
    n.headline?.toLowerCase().includes(team.name.toLowerCase()) ||
    n.headline?.toLowerCase().includes(team.shortName.toLowerCase())
  );

  return (
    <div className="container" style={{ paddingTop: 28, paddingBottom: 48 }}>
      <Link href={`/football/standings?league=${league}`} style={{ fontSize: 13, fontWeight: 500, color: "var(--text-secondary)", textDecoration: "none", display: "inline-block", marginBottom: 20 }}>
        ← {leagueName(league)}
      </Link>

      {/* Team header */}
      <div style={{ background: "var(--white)", border: "1px solid var(--border)", borderRadius: 14, padding: 24, marginBottom: 28, display: "flex", alignItems: "center", gap: 20, flexWrap: "wrap" }}>
        <TeamLogo logo={team.logo} shortName={team.shortName} size={64} highlight />
        <div>
          <h1 style={{ fontSize: "clamp(22px,4vw,28px)", fontWeight: 800, color: "var(--obsidian)", margin: "0 0 4px", letterSpacing: "-0.5px" }}>{team.name}</h1>
          <p style={{ fontSize: 13, color: "var(--text-muted)", margin: 0 }}>
            {[leagueName(league), team.venue, team.record].filter(Boolean).join(" · ")}
          </p>
        </div>
        {team.color && (
          <div style={{ marginLeft: "auto", width: 36, height: 36, borderRadius: "50%", background: team.color, border: "2px solid var(--border)", flexShrink: 0 }} title="Club colour" />
        )}
      </div>

      {/* Record breakdown */}
      {recordRaw && (
        <section style={{ marginBottom: 28 }}>
          <SectionLabel text="Record" />
          <TeamRecordCard data={recordRaw} />
        </section>
      )}

      {/* Schedule */}
      {scheduleRaw && (
        <section id="schedule" style={{ marginBottom: 28 }}>
          <SectionLabel text="Schedule" />
          <TeamScheduleList data={scheduleRaw} league={league} />
        </section>
      )}

      {/* Injuries */}
      {injuries.length > 0 && (
        <section style={{ marginBottom: 28 }}>
          <SectionLabel text="Injuries" />
          <InjuryList injuries={injuries} />
        </section>
      )}

      {/* Depth chart */}
      {depthRaw && (
        <section style={{ marginBottom: 28 }}>
          <SectionLabel text="Depth Chart" />
          <DepthChart data={depthRaw} />
        </section>
      )}

      {/* Team news */}
      {teamNews.length > 0 && (
        <section style={{ marginBottom: 28 }}>
          <SectionLabel text="Team News" />
          <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
            {teamNews.map(n => (
              <div key={n.id} style={{ background: "var(--white)", border: "1px solid var(--border)", borderRadius: 10, padding: "12px 14px", display: "flex", gap: 12 }}>
                {n.image && (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img src={n.image} alt={n.headline} style={{ width: 72, height: 48, borderRadius: 6, objectFit: "cover", flexShrink: 0 }} />
                )}
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ fontSize: 13, fontWeight: 600, color: "var(--obsidian)", lineHeight: 1.3, marginBottom: 4, display: "-webkit-box", WebkitLineClamp: 2, WebkitBoxOrient: "vertical", overflow: "hidden" }}>
                    {n.headline}
                  </div>
                  <div style={{ fontSize: 11, color: "var(--text-muted)" }}>{n.description?.slice(0, 100)}</div>
                </div>
              </div>
            ))}
          </div>
        </section>
      )}

      {/* Roster */}
      <SectionLabel text="Squad" />
      <SquadList roster={roster} league={league} teamId={id} />
    </div>
  );
}

function SectionLabel({ text }: { text: string }) {
  return (
    <h2 style={{ fontSize: 12, fontWeight: 700, color: "var(--text-muted)", textTransform: "uppercase", letterSpacing: "0.8px", marginBottom: 14 }}>{text}</h2>
  );
}